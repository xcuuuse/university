#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include "./tools/coordsinputwidget/coordsinputwidget.h"
#include "./tools/coordswidget/coordswidget.h"
#include "./tools/geopoint/geopoint.h"

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    void changeEvent(QEvent *e);

private slots:
    void onPointChanged(GeoPoint &p);

private:
    Ui::MainWindow *ui;

    CoordsWidget coordsWidget;
    CoordsInputWidget coordsInputWidget;
};

#endif // MAINWINDOW_H
