#ifndef COORDINPUTSWIDGET_H
#define COORDINPUTSWIDGET_H

#include "./../../tools/geopoint/geopoint.h"

#include <QWidget>

#include "ui_coordsinputwidget.h"

class CoordsInputWidget : public QWidget
{
	Q_OBJECT

public:
	CoordsInputWidget(QWidget *parent = 0);
	~CoordsInputWidget();

signals:
    void pointChanged(GeoPoint &p);

public slots:
	void setPoint(const GeoPoint &point); // Sets point coords and point coordinate system
	void setCoords(const GeoPoint &coords); // Sets coords according current coordindate system
	void setCoordinateSystemReadOnly(bool readOnly);
	void setReadOnly(bool readOnly);
        GeoPoint getPoint();
	bool isModified();

protected slots:
        void onCoordinateSystemComboBoxCurrentIndexChanged(int index);
	virtual void keyPressEvent(QKeyEvent *event);
	void showEvent(QShowEvent *event);
	void focusInEvent(QFocusEvent *event);
	void prepareLineEdits(GeoPoint::CoordinateSystem);
	void onCoordsChanged();

protected:
	GeoPoint point;
	bool modified;
    
private:
	Ui::CoordsInputWidgetClass ui;

private slots:
    void on_zLineEdit_textChanged(QString );
    void on_yLineEdit_textChanged(QString );
    void on_xLineEdit_textChanged(QString );
    void on_coordinateSystemComboBox_currentIndexChanged(int index);
};


#endif //COORDSINPUTWIDGET_H


