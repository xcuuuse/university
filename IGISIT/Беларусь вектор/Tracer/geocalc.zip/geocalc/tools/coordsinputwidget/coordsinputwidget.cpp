#include "coordsinputwidget.h"

#include <QKeyEvent>

const QChar DegreeSign = QChar(0x00B0);
const QChar MinuteSign = QChar(0x0027);
const QChar SecondSign = QChar(0x0022);

CoordsInputWidget::CoordsInputWidget(QWidget *parent) : QWidget(parent), point(), modified(false) {
    ui.setupUi(this);

    ui.coordinateSystemComboBox->addItem(tr("WGS-84"), GeoPoint::WGS84Geo);
    ui.coordinateSystemComboBox->addItem(tr("EP-90"), GeoPoint::EP90Geo);
    ui.coordinateSystemComboBox->addItem(tr("CS-42"), GeoPoint::CS42Geo);
    ui.coordinateSystemComboBox->addItem(tr("CS-95"), GeoPoint::CS95Geo);
    ui.coordinateSystemComboBox->addItem(tr("Gauss"), GeoPoint::GKPlane);

    connect(ui.coordinateSystemComboBox, SIGNAL(currentIndexChanged(int)),
            this, SLOT(onCoordinateSystemComboBoxCurrentIndexChanged(int)));
    ui.coordinateSystemComboBox->setCurrentIndex(0);

    connect(ui.xLineEdit, SIGNAL(textEdited(const QString &)), this, SLOT(onCoordsChanged()));
    connect(ui.yLineEdit, SIGNAL(textEdited(const QString &)), this, SLOT(onCoordsChanged()));
    connect(ui.zLineEdit, SIGNAL(textEdited(const QString &)), this, SLOT(onCoordsChanged()));
    connect(ui.coordinateSystemComboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(onCoordsChanged()));

    setFocusProxy(ui.xLineEdit);

    setPoint(GeoPoint());
}

CoordsInputWidget::~CoordsInputWidget() {

}

void CoordsInputWidget::setReadOnly(bool readOnly) {
    ui.xLineEdit->setReadOnly(readOnly);
    ui.yLineEdit->setReadOnly(readOnly);
    ui.zLineEdit->setReadOnly(readOnly);
    setCoordinateSystemReadOnly(readOnly);
}

void CoordsInputWidget::setCoordinateSystemReadOnly(bool readOnly) {
    ui.coordinateSystemComboBox->setEnabled(!readOnly);
}

void CoordsInputWidget::onCoordsChanged() {
    modified = true;
}

bool CoordsInputWidget::isModified() {
    return modified;
}

GeoPoint CoordsInputWidget::getPoint() {
    return GeoPoint(ui.xLineEdit->text(), ui.yLineEdit->text(), ui.zLineEdit->text(),
                    (GeoPoint::CoordinateSystem)ui.coordinateSystemComboBox->itemData(ui.coordinateSystemComboBox->currentIndex()).toInt());
}

void CoordsInputWidget::setPoint(const GeoPoint &point) {
    CoordsInputWidget::point = point;
    prepareLineEdits(point.getSystem());
    ui.coordinateSystemComboBox->blockSignals(true);
    ui.coordinateSystemComboBox->setCurrentIndex(ui.coordinateSystemComboBox->findData(point.getSystem()));
    ui.coordinateSystemComboBox->blockSignals(false);

    ui.xLineEdit->setText(point.getXString());
    ui.yLineEdit->setText(point.getYString());
    ui.zLineEdit->setText(point.getZString());

    modified = false;
}

void CoordsInputWidget::setCoords(const GeoPoint &) {

}

void CoordsInputWidget::onCoordinateSystemComboBoxCurrentIndexChanged(int index) {
    GeoPoint point = GeoPoint(0, 0, 0, (GeoPoint::CoordinateSystem)ui.coordinateSystemComboBox->itemData(index).toInt());
    setPoint(point);
    modified = true;
}

void CoordsInputWidget::prepareLineEdits(GeoPoint::CoordinateSystem system) {
    ui.xLineEdit->setInputMask(GeoPoint::getXMask(system));
    ui.xLineEdit->setValidator(GeoPoint::getXValidator(system));
    ui.yLineEdit->setInputMask(GeoPoint::getYMask(system));
    ui.yLineEdit->setValidator(GeoPoint::getYValidator(system));
    ui.zLineEdit->setInputMask(GeoPoint::getZMask(system));
    ui.zLineEdit->setValidator(GeoPoint::getZValidator(system));

    /*	ui.xLineEdit->setText("");
	ui.yLineEdit->setText("");
	ui.zLineEdit->setText("");*/
}

void CoordsInputWidget::showEvent(QShowEvent *) {
}

void CoordsInputWidget::keyPressEvent(QKeyEvent *event) {
    QWidget::keyPressEvent(event);
}

void CoordsInputWidget::focusInEvent(QFocusEvent *event) {
    QWidget::focusInEvent(event);
}


void CoordsInputWidget::on_coordinateSystemComboBox_currentIndexChanged(int)
{
    emit pointChanged(getPoint());
}

void CoordsInputWidget::on_xLineEdit_textChanged(QString )
{
    emit pointChanged(getPoint());
}

void CoordsInputWidget::on_yLineEdit_textChanged(QString )
{
    emit pointChanged(getPoint());
}

void CoordsInputWidget::on_zLineEdit_textChanged(QString )
{
    emit pointChanged(getPoint());
}
