VPATH += $$PWD

# Header files
HEADERS += coordsinputwidget/coordsinputwidget.h \
    coordswidget/coordswidget.h \
    geopoint/geopoint.h

# Source files
SOURCES += coordsinputwidget/coordsinputwidget.cpp \
    coordswidget/coordswidget.cpp \
    geopoint/geopoint.cpp
	
FORMS += coordsinputwidget/coordsinputwidget.ui \
         coordswidget/coordswidget.ui
