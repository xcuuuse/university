#ifndef COORDSWIDGET_H
#define COORDSWIDGET_H

#include "./../../tools/geopoint/geopoint.h"

#include <QWidget>

#include "ui_coordswidget.h"

class CoordsWidget : public QWidget
{
	Q_OBJECT

public:
	CoordsWidget(QWidget *parent = 0);
	~CoordsWidget();

public slots:
	GeoPoint::CoordinateSystem getCoordinateSystem();
	void setCoordinateSystem(GeoPoint::CoordinateSystem system);
	void startCoordinateSystemSelection();
        void setCoords(const GeoPoint &p);
    
protected slots:
	void onCoordinateSystemComboBoxCurrentIndexChanged(int index);
    
protected:
	void keyPressEvent(QKeyEvent *event);
	bool eventFilter(QObject *, QEvent *);
	GeoPoint coords;
    
private:
	Ui::CoordsWidgetClass ui;
};


#endif //COORDSWIDGET_H

