#include "coordswidget.h"

#include <QKeyEvent>

CoordsWidget::CoordsWidget(QWidget *parent) : QWidget(parent), coords() {
	ui.setupUi(this);

	ui.coordinateSystemComboBox->addItem(tr("WGS-84"), GeoPoint::WGS84Geo);
	ui.coordinateSystemComboBox->addItem(tr("EP-90"), GeoPoint::EP90Geo);
	ui.coordinateSystemComboBox->addItem(tr("CS-42"), GeoPoint::CS42Geo);
	ui.coordinateSystemComboBox->addItem(tr("CS-95"), GeoPoint::CS95Geo);
	ui.coordinateSystemComboBox->addItem(tr("Gauss"), GeoPoint::GKPlane);

	ui.xCaptionLabel->setProperty("pattern", "caption");
	ui.yCaptionLabel->setProperty("pattern", "caption");
	ui.zCaptionLabel->setProperty("pattern", "caption");
	ui.coordinateSystemCaptionLabel->setProperty("pattern", "caption");
	ui.xLabel->setProperty("pattern", "indicator");
	ui.yLabel->setProperty("pattern", "indicator");
	ui.zLabel->setProperty("pattern", "indicator");
	

    connect(ui.coordinateSystemComboBox, SIGNAL(currentIndexChanged(int)), 
			this, SLOT(onCoordinateSystemComboBoxCurrentIndexChanged(int)));
	ui.coordinateSystemComboBox->setCurrentIndex(0);

	ui.coordinateSystemComboBox->setFocusPolicy(Qt::NoFocus);

	//setFocusProxy(ui.coordinateSystemComboBox);



        setCoords(GeoPoint());
}

CoordsWidget::~CoordsWidget() {

}

bool CoordsWidget::eventFilter(QObject *, QEvent *) {
	return false;
}

void CoordsWidget::startCoordinateSystemSelection() {
    ui.coordinateSystemComboBox->showPopup();
}

GeoPoint::CoordinateSystem CoordsWidget::getCoordinateSystem() {
    return (GeoPoint::CoordinateSystem)ui.coordinateSystemComboBox->itemData(ui.coordinateSystemComboBox->currentIndex()).toInt();
}

void CoordsWidget::setCoordinateSystem(GeoPoint::CoordinateSystem system) {
    ui.coordinateSystemComboBox->setCurrentIndex(ui.coordinateSystemComboBox->findData(system));
}

void CoordsWidget::setCoords(const GeoPoint &p) {
        CoordsWidget::coords = p;
    GeoPoint point;
	GeoPoint::CoordinateSystem system = (GeoPoint::CoordinateSystem)ui.coordinateSystemComboBox->itemData(ui.coordinateSystemComboBox->currentIndex()).toInt();

    switch(system) {
	case GeoPoint::EP90Geo:
		point = coords.toEP90();
	break;
	case GeoPoint::CS42Geo:
		point = coords.toCS42();
	break;
	case GeoPoint::CS95Geo:
		point = coords.toCS95();
	break;
	case GeoPoint::GKPlane:
		point = coords.toPlaneGK();
	break;
	default:
	case GeoPoint::WGS84Geo:
		point = coords.toWGS84();
	break;
	}

//	ui.xCaptionLabel->setText(system == GeoPoint::GKPlane ? tr("X:") : tr("Latitude:"));
//	ui.yCaptionLabel->setText(system == GeoPoint::GKPlane ? tr("Y:") : tr("Longitude:"));
//	ui.zCaptionLabel->setText(tr("Altitude,m:"));

        ui.xLabel->setText(point.getXString());
        ui.yLabel->setText(point.getYString());
        ui.zLabel->setText(point.getZString());
}

void CoordsWidget::onCoordinateSystemComboBoxCurrentIndexChanged(int) {
    setCoords(coords);
}

void CoordsWidget::keyPressEvent(QKeyEvent *event) {
	event->ignore();
}

