#-------------------------------------------------
#
# Project created by QtCreator 2010-06-23T10:39:58
#
#-------------------------------------------------

TARGET = geocoordconvert
TEMPLATE = app


include(tools/tools.pri)

SOURCES += main.cpp\
        mainwindow.cpp

HEADERS  += mainwindow.h

FORMS    += mainwindow.ui
