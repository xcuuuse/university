#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->srcPointLayout->addWidget(&coordsInputWidget);
    ui->destPointLayout->addWidget(&coordsWidget);

    connect(&coordsInputWidget,SIGNAL(pointChanged(GeoPoint&)),this,SLOT(onPointChanged(GeoPoint&)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void MainWindow::onPointChanged(GeoPoint &p){
   coordsWidget.setCoords(p);
}

