<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ru_RU">
<context>
    <name>CoordsInputWidget</name>
    <message>
        <location filename="tools/coordsinputwidget/coordsinputwidget.cpp" line="12"/>
        <source>WGS-84</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tools/coordsinputwidget/coordsinputwidget.cpp" line="13"/>
        <source>EP-90</source>
        <translation>ПЗ-90</translation>
    </message>
    <message>
        <location filename="tools/coordsinputwidget/coordsinputwidget.cpp" line="14"/>
        <source>CS-42</source>
        <translation>СК-42</translation>
    </message>
    <message>
        <location filename="tools/coordsinputwidget/coordsinputwidget.cpp" line="15"/>
        <source>CS-95</source>
        <translation>СК-95</translation>
    </message>
    <message>
        <location filename="tools/coordsinputwidget/coordsinputwidget.cpp" line="16"/>
        <source>Gauss</source>
        <translation>Г-К</translation>
    </message>
</context>
<context>
    <name>CoordsInputWidgetClass</name>
    <message>
        <location filename="tools/coordsinputwidget/coordsinputwidget.ui" line="17"/>
        <source>Coordinates</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tools/coordsinputwidget/coordsinputwidget.ui" line="45"/>
        <source>System:</source>
        <translation>Система</translation>
    </message>
    <message>
        <location filename="tools/coordsinputwidget/coordsinputwidget.ui" line="82"/>
        <source>X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tools/coordsinputwidget/coordsinputwidget.ui" line="122"/>
        <source>Y</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tools/coordsinputwidget/coordsinputwidget.ui" line="159"/>
        <source>Z</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CoordsWidget</name>
    <message>
        <location filename="tools/coordswidget/coordswidget.cpp" line="8"/>
        <source>WGS-84</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tools/coordswidget/coordswidget.cpp" line="9"/>
        <source>EP-90</source>
        <translation>ПЗ-90</translation>
    </message>
    <message>
        <location filename="tools/coordswidget/coordswidget.cpp" line="10"/>
        <source>CS-42</source>
        <translation>СК-42</translation>
    </message>
    <message>
        <location filename="tools/coordswidget/coordswidget.cpp" line="11"/>
        <source>CS-95</source>
        <translation>СК-95</translation>
    </message>
    <message>
        <location filename="tools/coordswidget/coordswidget.cpp" line="12"/>
        <source>Gauss</source>
        <translation>Г-К</translation>
    </message>
</context>
<context>
    <name>CoordsWidgetClass</name>
    <message>
        <location filename="tools/coordswidget/coordswidget.ui" line="26"/>
        <source>Coords</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tools/coordswidget/coordswidget.ui" line="48"/>
        <source>System:</source>
        <translation>Система</translation>
    </message>
    <message>
        <location filename="tools/coordswidget/coordswidget.ui" line="116"/>
        <source>X:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tools/coordswidget/coordswidget.ui" line="153"/>
        <location filename="tools/coordswidget/coordswidget.ui" line="220"/>
        <location filename="tools/coordswidget/coordswidget.ui" line="269"/>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tools/coordswidget/coordswidget.ui" line="183"/>
        <source>Y:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="tools/coordswidget/coordswidget.ui" line="238"/>
        <source>Z:</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>GeoCoordConvert</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="21"/>
        <source>SrcPoint</source>
        <translation>Исходная точка</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="33"/>
        <source>DestPoint</source>
        <translation>Переведенная точка</translation>
    </message>
</context>
</TS>
