#include <QtGui/QApplication>
#include <QTranslator>
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QApplication::setStyle("cleanlooks");

    QTranslator t;
    t.load("geocalc_ru");
    a.installTranslator(&t);

    MainWindow w;
    w.show();
    return a.exec();
}
